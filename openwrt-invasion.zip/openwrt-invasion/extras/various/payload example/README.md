# This is an already created payload with the following information
```
netcat_port: 4444
attacker_ip_address: 192.168.0.13
router_ip_address: 192.168.0.21
```